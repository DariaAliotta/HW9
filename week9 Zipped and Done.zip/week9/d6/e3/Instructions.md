# Implementing Abstract and Non-Abstract Methods in a Animal Management System

## Objective
Learn how to use abstract classes and methods in Java, override and implement abstract methods, and call both abstract and implemented methods from the parent class in the child class. In this exercise, you'll manage different types of vehicles, demonstrating inheritance and abstraction.

## Instructions

**Step 1: Create the `Animal` Abstract Class**

1. **Create the `Animal.java` Abstract class** with the following:
   - **Abstract Methods:**
      - Declare an abstract method `makeSound()` with no parameters.
      - Declare an abstract method `move()` with no parameters.
   
**Step 2: Create the `Dog and Bird` Classes**

1. **Create the `Dog.java` class** as a subclass of `Animal`:
      - **Override the `makeSound()` Method:**
         - Provide the implementation for the `makeSound()` method and implement the logic to display `The Dog makes sound by Barking`.
      - **Override the `move()` Method:**
         - Provide the implementation for the `move()` method and implement the logic to display `The Dog moves by Running`.
2. **Create the `Bird.java` class** as a subclass of `Animal`:
    - **Override the `makeSound()` Method:**
        - Provide the implementation for the `makeSound()` method and implement the logic to display `The Bird makes sound by Chirping`.
    - **Override the `move()` Method:**
        - Provide the implementation for the `makeSound()` method and implement the logic to display `The Bird moves by Flying`.

**Step 3: In the `E3AbstractClass` Class:** 

   - **Main Method (In `E3AbstractClass`):**
       - Create an object of the `Animal` class using Dog class constructor.
       - Call  the `makeSound()` and `move()` methods.
       - Create an object of the `Animal` class using Dog class constructor. 
       - Call  the `makeSound()` and `move()` methods.



## Example Output:

**Expected Output:**

```plaintext
The Dog makes sound by Barking
The Dog moves by Running                                                                                                                   
The Bird makes sound by Chirping
The Bird moves by Flying
```

**Explanation:**
- The `makeSound`,`move()`  methods are abstract in the parent class `Animal` and must be implemented in the `Dog` and `Bird` classes.
**Step 3: Run Your Application**

1. Execute your program to verify that the output matches the expected result.

## Tips:

- **Abstract Methods:** Abstract methods must be implemented in any subclass that extends the abstract class.
- **Method Overloading and Overriding:** Method overloading allows you to define multiple methods with the same name but different parameters. Overriding is used when the child class provides its own implementation for a method from the parent class.

By completing this exercise, you will gain a clear understanding of how to work with abstract classes, method overriding, and method overloading in a real-life vehicle management system. Happy coding!
